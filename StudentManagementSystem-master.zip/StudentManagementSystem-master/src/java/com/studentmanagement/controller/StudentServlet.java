package com.studentmanagement.controller;

import com.studentmanagement.dao.StudentDAO;
import com.studentmanagement.model.Student;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/StudentServlet")
public class StudentServlet extends HttpServlet {

    private StudentDAO studentDAO;

    @Override
    public void init() {
        studentDAO = new StudentDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request,
                         HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");


        // DELETE
        if ("delete".equals(action)) {

            int id = Integer.parseInt(request.getParameter("id"));

            studentDAO.deleteStudent(id);

            response.sendRedirect("StudentServlet");

        }


        // EDIT
        else if ("edit".equals(action)) {

            int id = Integer.parseInt(request.getParameter("id"));

            Student student = studentDAO.getStudentById(id);

            request.setAttribute("student", student);

            RequestDispatcher dispatcher =
                    request.getRequestDispatcher("edit-student.jsp");

            dispatcher.forward(request, response);

        }


        // SEARCH
        else if ("search".equals(action)) {

            String keyword = request.getParameter("keyword");

            if (keyword == null) {
                keyword = "";
            }

            List<Student> students =
                    studentDAO.searchStudents(keyword);

            request.setAttribute("students", students);

            request.setAttribute("searchKeyword", keyword);

            RequestDispatcher dispatcher =
                    request.getRequestDispatcher("students.jsp");

            dispatcher.forward(request, response);

        }


        // DISPLAY ALL STUDENTS
        else {

            List<Student> students =
                    studentDAO.getAllStudents();

            request.setAttribute("students", students);

            RequestDispatcher dispatcher =
                    request.getRequestDispatcher("students.jsp");

            dispatcher.forward(request, response);
        }
    }


    @Override
    protected void doPost(HttpServletRequest request,
                          HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");


        // UPDATE STUDENT
        if ("update".equals(action)) {

            int id =
                    Integer.parseInt(request.getParameter("id"));

            String name =
                    request.getParameter("name");

            String email =
                    request.getParameter("email");

            String course =
                    request.getParameter("course");

            String phone =
                    request.getParameter("phone");


            Student student = new Student();

            student.setId(id);
            student.setName(name);
            student.setEmail(email);
            student.setCourse(course);
            student.setPhone(phone);


            studentDAO.updateStudent(student);

            response.sendRedirect("StudentServlet");

        }


        // ADD STUDENT
        else {

            String name =
                    request.getParameter("name");

            String email =
                    request.getParameter("email");

            String course =
                    request.getParameter("course");

            String phone =
                    request.getParameter("phone");


            Student student = new Student();

            student.setName(name);
            student.setEmail(email);
            student.setCourse(course);
            student.setPhone(phone);


            studentDAO.addStudent(student);

            response.sendRedirect("StudentServlet");
        }
    }
}
