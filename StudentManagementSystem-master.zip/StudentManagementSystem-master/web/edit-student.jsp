<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<%@ page import="com.studentmanagement.model.Student" %>

<%
    Student student = (Student) request.getAttribute("student");
%>

<!DOCTYPE html>
<html>
<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Edit Student</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">


    <style>

        :root {
            --moonlit-cream: #E3EDD8;
            --mist-sage: #A8B8A2;
            --candle-blush: #D7A08D;
            --mulled-garnet: #873745;
            --cypress-shadow: #405143;
            --cream-light: #F5F7F0;
            --white: #FFFFFF;
            --text-dark: #29352D;
        }


        body {
            margin: 0;

            font-family: "Segoe UI", Arial, sans-serif;

            background:
                linear-gradient(
                    135deg,
                    var(--moonlit-cream),
                    var(--mist-sage)
                );

            min-height: 100vh;

            color: var(--text-dark);
        }


        /* Navbar */

        .navbar-custom {
            background: var(--cypress-shadow);

            padding: 16px 0;

            box-shadow:
                0 5px 20px rgba(64, 81, 67, 0.25);
        }


        .navbar-brand {
            color: var(--moonlit-cream) !important;

            font-size: 22px;

            font-weight: 700;
        }


        .navbar-brand i {
            color: var(--candle-blush);
        }


        .home-btn {
            background: var(--moonlit-cream);

            color: var(--cypress-shadow);

            border: none;

            border-radius: 9px;

            padding: 8px 17px;

            font-weight: 600;
        }


        .home-btn:hover {
            background: var(--candle-blush);

            color: white;
        }


        /* Main */

        .main-container {
            max-width: 850px;

            margin: 55px auto;

            padding: 0 15px;
        }


        .page-title {
            color: var(--cypress-shadow);

            font-size: 36px;

            font-weight: 700;
        }


        .page-subtitle {
            color: #59665C;

            margin-bottom: 30px;
        }


        /* Card */

        .edit-card {
            background: var(--cream-light);

            border: none;

            border-radius: 18px;

            overflow: hidden;

            box-shadow:
                0 12px 30px rgba(64, 81, 67, 0.20);
        }


        .card-header-custom {
            background: var(--cypress-shadow);

            color: var(--moonlit-cream);

            padding: 18px 24px;

            font-size: 18px;

            font-weight: 600;

            border-bottom: 4px solid var(--candle-blush);
        }


        .card-header-custom i {
            color: var(--candle-blush);
        }


        /* Form */

        .form-label {
            color: var(--cypress-shadow);

            font-weight: 600;
        }


        .form-label i {
            color: var(--mulled-garnet);
        }


        .form-control {
            background: white;

            border: 1px solid var(--mist-sage);

            border-radius: 10px;

            padding: 12px 14px;
        }


        .form-control:focus {
            border-color: var(--mulled-garnet);

            box-shadow:
                0 0 0 3px rgba(135, 55, 69, 0.13);
        }


        /* Buttons */

        .btn-update {
            background: var(--mulled-garnet);

            color: white;

            border: none;

            border-radius: 9px;

            padding: 11px 24px;

            font-weight: 600;

            transition: 0.2s;
        }


        .btn-update:hover {
            background: #6E2C39;

            color: white;

            transform: translateY(-2px);
        }


        .btn-cancel {
            background: var(--mist-sage);

            color: var(--cypress-shadow);

            border: none;

            border-radius: 9px;

            padding: 11px 24px;

            font-weight: 600;

            text-decoration: none;

            display: inline-block;

            margin-left: 8px;
        }


        .btn-cancel:hover {
            background: var(--candle-blush);

            color: var(--cypress-shadow);
        }


        /* Footer */

        .footer {
            text-align: center;

            color: #59665C;

            margin-top: 30px;

            padding-bottom: 25px;
        }


        .footer i {
            color: var(--mulled-garnet);
        }

    </style>

</head>


<body>


<!-- Navbar -->

<nav class="navbar navbar-custom">

    <div class="container">

        <a class="navbar-brand"
           href="index.html">

            <i class="bi bi-mortarboard-fill me-2"></i>

            Student Management System

        </a>


        <a href="StudentServlet"
           class="btn home-btn">

            <i class="bi bi-arrow-left me-1"></i>

            Student List

        </a>

    </div>

</nav>



<!-- Main -->

<div class="container main-container">


    <h1 class="page-title">

        <i class="bi bi-pencil-square me-2"></i>

        Edit Student

    </h1>


    <p class="page-subtitle">

        Update the student's information below.

    </p>



    <!-- Edit Card -->

    <div class="card edit-card">


        <div class="card-header-custom">

            <i class="bi bi-person-gear me-2"></i>

            Student Information

        </div>


        <div class="card-body p-4">


            <form action="StudentServlet"
                  method="post">


                <!-- Hidden ID -->

                <input type="hidden"
                       name="id"
                       value="<%= student.getId() %>">


                <input type="hidden"
                       name="action"
                       value="update">



                <div class="row">


                    <!-- Name -->

                    <div class="col-md-6 mb-3">

                        <label class="form-label">

                            <i class="bi bi-person me-1"></i>

                            Student Name

                        </label>


                        <input type="text"
                               name="name"
                               class="form-control"
                               value="<%= student.getName() %>"
                               required>

                    </div>



                    <!-- Email -->

                    <div class="col-md-6 mb-3">

                        <label class="form-label">

                            <i class="bi bi-envelope me-1"></i>

                            Email

                        </label>


                        <input type="email"
                               name="email"
                               class="form-control"
                               value="<%= student.getEmail() %>"
                               required>

                    </div>



                    <!-- Course -->

                    <div class="col-md-6 mb-3">

                        <label class="form-label">

                            <i class="bi bi-book me-1"></i>

                            Course

                        </label>


                        <input type="text"
                               name="course"
                               class="form-control"
                               value="<%= student.getCourse() %>"
                               required>

                    </div>



                    <!-- Phone -->

                    <div class="col-md-6 mb-3">

                        <label class="form-label">

                            <i class="bi bi-telephone me-1"></i>

                            Phone

                        </label>


                        <input type="text"
                               name="phone"
                               class="form-control"
                               value="<%= student.getPhone() %>">

                    </div>

                </div>



                <!-- Buttons -->

                <button type="submit"
                        class="btn btn-update">

                    <i class="bi bi-check-circle me-2"></i>

                    Update Student

                </button>


                <a href="StudentServlet"
                   class="btn btn-cancel">

                    <i class="bi bi-x-circle me-1"></i>

                    Cancel

                </a>


            </form>

        </div>

    </div>



    <!-- Footer -->

    <div class="footer">

        <i class="bi bi-mortarboard-fill me-1"></i>

        Student Management System

        <br>

        <small>

            Built with Java • JSP • Servlet • MySQL

        </small>

    </div>


</div>


</body>
</html>