<%@ page contentType="text/html;charset=UTF-8" language="java" %>

<!DOCTYPE html>
<html>

<head>

    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Student Management</title>

    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css"
          rel="stylesheet">

    <!-- Bootstrap Icons -->
    <link rel="stylesheet"
          href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css">


    <style>

        /* =====================================================
           COLOR PALETTE
           ===================================================== */

        :root {

            --moonlit-cream: #EFF6FF;
            --mist-sage: #60A5FA;
            --candle-blush: #93C5FD;
            --mulled-garnet: #2563EB;
            --cypress-shadow: #172B4D;

            --cream-light: #FFFFFF;
            --white: #FFFFFF;
            --text-dark: #1E293B;

        }


        /* =====================================================
           BODY
           ===================================================== */

        body {

            margin: 0;

            font-family: "Segoe UI", Arial, sans-serif;

            background:
                linear-gradient(
                    135deg,
                    var(--moonlit-cream),
                    var(--mist-sage)
                );

            min-height: 100vh;

            color: var(--text-dark);

        }


        /* =====================================================
           NAVBAR
           ===================================================== */

        .navbar-custom {

            background: var(--cypress-shadow);

            padding: 16px 0;

            box-shadow:
                0 5px 20px rgba(23, 43, 77, 0.25);

        }


        .navbar-brand {

            color: var(--moonlit-cream) !important;

            font-size: 22px;

            font-weight: 700;

            letter-spacing: 0.3px;

        }


        .navbar-brand i {

            color: var(--candle-blush);

        }


        .home-btn {

            background: var(--moonlit-cream);

            color: var(--cypress-shadow);

            border: none;

            border-radius: 9px;

            padding: 8px 17px;

            font-weight: 600;

            transition: 0.25s;

        }


        .home-btn:hover {

            background: var(--candle-blush);

            color: var(--white);

            transform: translateY(-2px);

        }


        /* =====================================================
           MAIN CONTAINER
           ===================================================== */

        .main-container {

            max-width: 1200px;

            margin: 45px auto;

            padding: 0 15px;

        }


        /* =====================================================
           PAGE TITLE
           ===================================================== */

        .page-title {

            color: var(--cypress-shadow);

            font-size: 38px;

            font-weight: 700;

            margin-bottom: 8px;

        }


        .page-title i {

            color: var(--mulled-garnet);

        }


        .page-subtitle {

            color: #64748B;

            font-size: 16px;

            margin-bottom: 30px;

        }


        /* =====================================================
           CARDS
           ===================================================== */

        .custom-card {

            border: none;

            border-radius: 18px;

            overflow: hidden;

            background: var(--cream-light);

            box-shadow:
                0 12px 30px rgba(23, 43, 77, 0.15);

        }


        .card-header-custom {

            background: var(--cypress-shadow);

            color: var(--moonlit-cream);

            padding: 18px 24px;

            font-size: 18px;

            font-weight: 600;

            border-bottom: 4px solid var(--candle-blush);

        }


        .card-header-custom i {

            color: var(--candle-blush);

        }


        /* =====================================================
           FORM
           ===================================================== */

        .form-label {

            color: var(--cypress-shadow);

            font-weight: 600;

            margin-bottom: 7px;

        }


        .form-label i {

            color: var(--mulled-garnet);

        }


        .form-control {

            background: var(--white);

            color: var(--text-dark);

            border: 1px solid var(--mist-sage);

            border-radius: 10px;

            padding: 12px 14px;

            transition: 0.2s;

        }


        .form-control::placeholder {

            color: #94A3B8;

        }


        .form-control:focus {

            background: var(--white);

            color: var(--text-dark);

            border-color: var(--mulled-garnet);

            box-shadow:
                0 0 0 3px rgba(37, 99, 235, 0.13);

        }


        /* =====================================================
           ADD BUTTON
           ===================================================== */

        .btn-add {

            background: var(--mulled-garnet);

            color: var(--white);

            border: none;

            border-radius: 9px;

            padding: 11px 25px;

            font-weight: 600;

            transition: 0.25s;

        }


        .btn-add:hover {

            background: #1D4ED8;

            color: var(--white);

            transform: translateY(-2px);

            box-shadow:
                0 7px 18px rgba(37, 99, 235, 0.25);

        }


        /* =====================================================
           TABLE
           ===================================================== */

        .student-table {

            margin-bottom: 0;

            color: var(--text-dark);

        }


        .student-table thead {

            background: var(--cypress-shadow);

            color: var(--moonlit-cream);

        }


        .student-table th {

            padding: 15px;

            font-weight: 600;

            border: none;

            white-space: nowrap;

        }


        .student-table td {

            padding: 14px;

            vertical-align: middle;

            border-color: #D9E2F2;

        }


        .student-table tbody tr {

            background: var(--cream-light);

            transition: 0.2s;

        }


        .student-table tbody tr:hover {

            background: var(--moonlit-cream);

        }


        /* =====================================================
           ID BADGE
           ===================================================== */

        .id-badge {

            display: inline-block;

            background: var(--mist-sage);

            color: var(--cypress-shadow);

            padding: 5px 11px;

            border-radius: 20px;

            font-size: 13px;

            font-weight: 700;

        }


        /* =====================================================
           COURSE BADGE
           ===================================================== */

        .course-badge {

            display: inline-block;

            background: var(--candle-blush);

            color: var(--cypress-shadow);

            padding: 6px 11px;

            border-radius: 20px;

            font-size: 12px;

            font-weight: 700;

        }


        /* =====================================================
           EDIT BUTTON
           ===================================================== */

        .btn-edit {

            background: var(--candle-blush);

            color: var(--cypress-shadow);

            border: 1px solid var(--candle-blush);

            border-radius: 8px;

            padding: 6px 12px;

            font-size: 13px;

            font-weight: 600;

            transition: 0.2s;

        }


        .btn-edit:hover {

            background: var(--mulled-garnet);

            color: var(--white);

            border-color: var(--mulled-garnet);

        }


        /* =====================================================
           DELETE BUTTON
           ===================================================== */

        .btn-delete {

            background: transparent;

            color: var(--mulled-garnet);

            border: 1px solid var(--mulled-garnet);

            border-radius: 8px;

            padding: 6px 12px;

            font-size: 13px;

            font-weight: 600;

            transition: 0.2s;

        }


        .btn-delete:hover {

            background: var(--mulled-garnet);

            color: var(--white);

            border-color: var(--mulled-garnet);

        }


        /* =====================================================
           SEARCH BUTTON
           ===================================================== */

        .search-btn {

            background: var(--mulled-garnet);

            color: var(--white);

            border: none;

            border-radius: 9px;

            padding: 11px 20px;

            font-weight: 600;

        }


        .search-btn:hover {

            background: #1D4ED8;

            color: var(--white);

        }


        /* =====================================================
           EMPTY STATE
           ===================================================== */

        .empty-icon {

            color: var(--mist-sage);

            font-size: 48px;

        }


        .empty-text {

            color: #64748B;

        }


        /* =====================================================
           FOOTER
           ===================================================== */

        .footer {

            text-align: center;

            color: #64748B;

            margin-top: 35px;

            padding-bottom: 25px;

            font-size: 14px;

        }


        .footer i {

            color: var(--mulled-garnet);

        }


        /* =====================================================
           RESPONSIVE
           ===================================================== */

        @media (max-width: 768px) {

            .page-title {

                font-size: 29px;

            }


            .main-container {

                margin-top: 30px;

            }


            .navbar-brand {

                font-size: 18px;

            }

        }

    </style>

</head>


<body>


<!-- =====================================================
     NAVBAR
     ===================================================== -->

<nav class="navbar navbar-custom">

    <div class="container">

        <a class="navbar-brand" href="index.html">

            <i class="bi bi-mortarboard-fill me-2"></i>

            Student Management System

        </a>


        <a href="index.html"
           class="btn home-btn">

            <i class="bi bi-house-fill me-1"></i>

            Home

        </a>

    </div>

</nav>



<!-- =====================================================
     MAIN CONTENT
     ===================================================== -->

<div class="container main-container">


    <!-- PAGE TITLE -->

    <div>

        <h1 class="page-title">

            <i class="bi bi-people-fill me-2"></i>

            Student Management

        </h1>


        <p class="page-subtitle">

            Add, view and manage student records from one place.

        </p>

    </div>



    <!-- =================================================
         ADD STUDENT
         ================================================= -->

    <div class="card custom-card mb-4">


        <div class="card-header-custom">

            <i class="bi bi-person-plus-fill me-2"></i>

            Add New Student

        </div>


        <div class="card-body p-4">


            <form action="StudentServlet" method="post">


                <div class="row">


                    <!-- NAME -->

                    <div class="col-md-6 mb-3">

                        <label class="form-label">

                            <i class="bi bi-person me-1"></i>

                            Student Name

                        </label>


                        <input type="text"
                               name="name"
                               class="form-control"
                               placeholder="Enter student name"
                               required>

                    </div>



                    <!-- EMAIL -->

                    <div class="col-md-6 mb-3">

                        <label class="form-label">

                            <i class="bi bi-envelope me-1"></i>

                            Email

                        </label>


                        <input type="email"
                               name="email"
                               class="form-control"
                               placeholder="student@example.com"
                               required>

                    </div>



                    <!-- COURSE -->

                    <div class="col-md-6 mb-3">

                        <label class="form-label">

                            <i class="bi bi-book me-1"></i>

                            Course

                        </label>


                        <input type="text"
                               name="course"
                               class="form-control"
                               placeholder="Enter course"
                               required>

                    </div>



                    <!-- PHONE -->

                    <div class="col-md-6 mb-3">

                        <label class="form-label">

                            <i class="bi bi-telephone me-1"></i>

                            Phone

                        </label>


                        <input type="text"
                               name="phone"
                               class="form-control"
                               placeholder="Enter phone number">

                    </div>

                </div>


                <button type="submit"
                        class="btn btn-add">

                    <i class="bi bi-plus-circle me-2"></i>

                    Add Student

                </button>


            </form>

        </div>

    </div>



    <!-- =================================================
         STUDENT RECORDS
         ================================================= -->

    <div class="card custom-card">


        <div class="card-header-custom">

            <i class="bi bi-table me-2"></i>

            Student Records

        </div>


        <!-- =================================================
             SEARCH STUDENTS
             ================================================= -->

        <div class="p-3"
             style="background: var(--cream-light);">

            <form action="StudentServlet"
                  method="get"
                  class="row g-2 align-items-center">

                <input type="hidden"
                       name="action"
                       value="search">


                <div class="col-md-9">

                    <div class="input-group">

                        <span class="input-group-text"
                              style="
                              background: var(--mist-sage);
                              border-color: var(--mist-sage);
                              color: var(--cypress-shadow);
                              ">

                            <i class="bi bi-search"></i>

                        </span>


                        <input type="text"
                               name="keyword"
                               class="form-control"
                               placeholder="Search by name, email, course or phone"
                               value="<%= request.getAttribute("searchKeyword") != null
                                       ? request.getAttribute("searchKeyword")
                                       : "" %>">

                    </div>

                </div>


                <div class="col-md-3 d-flex gap-2">

                    <button type="submit"
                            class="btn search-btn flex-grow-1">

                        <i class="bi bi-search me-1"></i>

                        Search

                    </button>


                    <a href="StudentServlet"
                       class="btn btn-delete">

                        <i class="bi bi-arrow-clockwise"></i>

                    </a>

                </div>

            </form>

        </div>



        <!-- =================================================
             STUDENT TABLE
             ================================================= -->

        <div class="table-responsive">


            <table class="table table-hover student-table">


                <thead>

                    <tr>

                        <th>ID</th>

                        <th>Name</th>

                        <th>Email</th>

                        <th>Course</th>

                        <th>Phone</th>

                        <th>Action</th>

                    </tr>

                </thead>


                <tbody>


                    <%

                        java.util.List<com.studentmanagement.model.Student> students =

                                (java.util.List<com.studentmanagement.model.Student>)

                                request.getAttribute("students");


                        if (students != null && !students.isEmpty()) {


                            for (com.studentmanagement.model.Student student : students) {

                    %>


                    <tr>


                        <td>

                            <span class="id-badge">

                                <%= student.getId() %>

                            </span>

                        </td>


                        <td>

                            <strong>

                                <%= student.getName() %>

                            </strong>

                        </td>


                        <td>

                            <%= student.getEmail() %>

                        </td>


                        <td>

                            <span class="course-badge">

                                <%= student.getCourse() %>

                            </span>

                        </td>


                        <td>

                            <%= student.getPhone() %>

                        </td>


                        <td>


                            <!-- EDIT -->

                            <a href="StudentServlet?action=edit&id=<%= student.getId() %>"
                               class="btn btn-edit me-1">

                                <i class="bi bi-pencil-square me-1"></i>

                                Edit

                            </a>


                            <!-- DELETE -->

                            <a href="StudentServlet?action=delete&id=<%= student.getId() %>"
                               class="btn btn-delete"
                               onclick="return confirm('Are you sure you want to delete this student?');">

                                <i class="bi bi-trash3-fill me-1"></i>

                                Delete

                            </a>


                        </td>


                    </tr>


                    <%

                            }

                        } else {

                    %>


                    <tr>

                        <td colspan="6"
                            class="text-center py-5">

                            <i class="bi bi-people empty-icon"></i>

                            <p class="mt-3 mb-0 empty-text">

                                No students found.

                            </p>

                        </td>

                    </tr>


                    <%

                        }

                    %>


                </tbody>


            </table>


        </div>

    </div>



    <!-- FOOTER -->

    <div class="footer">

        <i class="bi bi-mortarboard-fill me-1"></i>

        Student Management System

        <br>

        <small>

            Built with Java • JSP • Servlet • MySQL

        </small>

    </div>


</div>


</body>

</html>